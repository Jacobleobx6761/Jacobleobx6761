-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : jeu. 23 mars 2023 à 21:31
-- Version du serveur : 10.5.19-MariaDB
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `sophosgame_db`
--
CREATE DATABASE IF NOT EXISTS `sophosgame_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sophosgame_db`;

-- --------------------------------------------------------

--
-- Structure de la table `commentaires`
--

CREATE TABLE `commentaires` (
  `id` int(11) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `commentaire` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL,
  `pseudo` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `ip` varchar(20) NOT NULL,
  `token` text NOT NULL,
  `date_inscription` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `pseudo`, `email`, `password`, `ip`, `token`, `date_inscription`) VALUES
(2, 'jacob', 'jacob@gamil.com', '$2y$12$HZptUR4J95XR/OZnTOL0cO9wSRhS3tCtJoJiM/YTseeiEGvrROm16', '::1', '5f224633a1de89d82354a4492623b6b3f9279bfe35900d7ee53cff961753329075843d6d47cb378d7eb10d56c67f15c62a61e454a196e9b2d3814f8ed26bfb0b', '2023-01-02 02:49:58'),
(3, 'jacob', 'jacob@gmail.com', '$2y$12$LSJ6luCm.KM.hFuUh27pEOdwVwv7c4ThqCSqrAD0NtCSAPTAa9FmC', '::1', '3eab514a656891efcc162924ca69907dacaab2db6ebf3d96f2968b94c191337898b8fb12fbeb07134334039b534befffd461c433aaea5112596d20507e16ba7b', '2023-01-02 03:06:26'),
(4, 'jc ', 'hi@gmail.com', '$2y$12$hdun0CrOwy3ao4hudxha5e0AAEkhotN60EpMULFiAMKl.UmKXPEIS', '::1', 'd1cb19a1621fcb0d1e50873f0e3e8ee30729865f5524a7b0dbae9c26a2f3735578e881a0e09ff16ef0ac517c3bc033f62b0b82438cec0186cb00909416433e1b', '2023-02-24 16:47:20'),
(5, 'jaco', 'jac@gmail.com', '$2y$12$diDneP7j/Afm57fwNHV.VOB.NB5AWQYBhtPaDdu5HrNl6MJZkeTxm', '::1', '5e285c5fadfb37cee671f8af3fe905fccda99fd3e6fdfff6d1c8ba50642bbbdeff22735e2ecf6f7df9c809b63e622b01bfb4fd7c179931878c2f01f28b7a235d', '2023-02-24 17:41:44'),
(6, 'jc', 'timothy@gmail.com', '$2y$12$MxLelo8z8Iq8IaxrZR0Qi.pJyItisOAUlkoK4jsXnn25VaQQVadya', '197.234.219.58', 'd0d5679519e8bcfe128fcf4f61f08801ec0f551d316f157e7d2a5c6fb0b721e7605a411574d945243faaec74666271d7dcd93d80fd4c2eaa56c5dbc212fee80d', '2023-02-25 12:47:21'),
(7, 'Sophos', 'hougniothniel13@gmail.com', '$2y$12$fLMUApHTZHyFNEWX8lOi1.FLdGL4T66fu6vLveiVc1E2lSbgKmWlO', '41.79.219.203', 'c3565c24a66a79c80bc5a5f3c86f38b19f8e552e64f803375c0e2d89ecbf9bc0b0691520befe7fea4ab289500abf9ec81dc8a441954496fef9c7c0ecefeb6fa5', '2023-02-25 13:12:06'),
(8, 'legrand', 'legrand@lagrand.com', '$2y$12$UzRUc2lFP7jWFrAEig0vU.gbP0PMuKwi9XIWcTdKaBBU5XSkaWXHq', '41.85.168.134', '73193a4310d958fb37f3609890f18054606fbdc8c0e8202803734f6fc16520d7704ca1211e310dcf9982723287c97004ddefc2eb4e792c01c14b126169378442', '2023-03-02 14:48:29');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `commentaires`
--
ALTER TABLE `commentaires`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `commentaires`
--
ALTER TABLE `commentaires`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
